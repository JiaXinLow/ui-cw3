#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "datapage/window.hpp"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , dataPage(new WaterQualityWindow(this))
{
    ui->setupUi(this);
    ui->tabWidget->addTab(dataPage, "Water Quality Datapage");
}

MainWindow::~MainWindow()
{
    delete ui;
}
