#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "datapage/window.hpp"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , dataPage(new WaterQualityWindow(this))
{
    ui->setupUi(this);

    if (ui->tabWidget->count() > 0) {
        ui->tabWidget->removeTab(0);
        ui->tabWidget->insertTab(0, dataPage, "Main Dashboard");
    } else {
        ui->tabWidget->addTab(dataPage, "Main Dashboard");
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}
