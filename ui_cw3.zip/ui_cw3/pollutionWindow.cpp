#include <QLineEdit>
#include <QListView>
#include <QStringListModel>
#include <QVBoxLayout>
#include <QLabel>
#include <QTableView>
#include <QTableWidget>
#include <QHeaderView>
#include <QSizePolicy>
#include <QFont>
#include <QMap>
#include <QListWidget>
#include <QFrame>
#include <QFile>
#include <iostream>
#include <QMessageBox>
#include "pollutionWindow.hpp"
#include "model.hpp"
#include "dataset.hpp"
#include "watersample.hpp"
#include "stats.hpp"

PollutionWindow::PollutionWindow(QWidget* parent)
    : QWidget(parent) // Initialize the model pointer
{
    createMainWidget();
}

void PollutionWindow::createMainWidget()
{
    // Title Label
    QLabel* titleLabel = new QLabel("Pollution Overview Page", this);
    titleLabel->setAlignment(Qt::AlignCenter);
    titleLabel->setFont(QFont("Times New Roman", 20));  // Set font to Times New Roman, 20pt
    titleLabel->setFixedHeight(55);

    // List of items (pollutants)
    QStringList items = {
        "1,1,2-Trichloroethane",
        "Cadmium, Dissolved",
        "Chloroform",
        "Lead, Dissolved",
        "Mercury, Dissolved",
        "Nitrate-N",
        "Nitrite-N",
        "Phosphorus-P"
    };

    pollutantDescriptions["1,1,2-Trichloroethane"] =
        "This chemical is used as a solvent and is harmful to both human health and aquatic life when released into water bodies.";
    pollutantDescriptions["Cadmium, Dissolved"] =
        "Cadmium is a highly toxic element, especially harmful to the kidneys, liver, and bones, and it can accumulate in the environment.";
    pollutantDescriptions["Chloroform"] =
        "Chloroform, a chlorinated solvent, is considered a potential carcinogen and is toxic to aquatic life.";
    pollutantDescriptions["Lead, Dissolved"] =
        "Lead contamination in water can cause developmental and neurological impairments, particularly in children.";
    pollutantDescriptions["Mercury, Dissolved"] =
        "Mercury, a toxic heavy metal, can accumulate in aquatic environments, causing severe ecological and human health risks.";
    pollutantDescriptions["Nitrate-N"] =
        "Nitrate in water can cause eutrophication and health problems, especially methemoglobinemia in infants.";
    pollutantDescriptions["Nitrite-N"] =
        "Nitrites in water can lead to water toxicity and are linked to adverse health effects such as blue baby syndrome.";
    pollutantDescriptions["Phosphorus-P"] =
        "Phosphorus is a key nutrient in water bodies, but excess amounts can lead to algal blooms and oxygen depletion.";

    // Create QLineEdit for the search bar
    QLineEdit* searchLineEdit = new QLineEdit(this);
    searchLineEdit->setPlaceholderText("Search for a pollutant...");

    // Create a QStringListModel to hold the list of items
    QStringListModel* model = new QStringListModel(items, this);

    // Create a QListView to display the list of items
    QListView* listView = new QListView(this);
    listView->setModel(model);
    listView->setFont(QFont("Times New Roman", 12));

    // Create a QLabel for displaying pollutant description
    QLabel* descriptionLabel = new QLabel(this);  // Declare here
    descriptionLabel->setWordWrap(true);  // Enable word wrapping
    descriptionLabel->setAlignment(Qt::AlignTop | Qt::AlignLeft);  // Align text to the top-left

    // Filter the list based on the text entered in the QLineEdit
    connect(searchLineEdit, &QLineEdit::textChanged, [=](const QString& text) {
        // Filter the model based on the search text
        QStringList filteredItems = items.filter(text, Qt::CaseInsensitive);
        model->setStringList(filteredItems);  // Update the model with filtered items
    });

    // When an item is selected in the list view, update the description label
    connect(listView, &QListView::clicked, [=](const QModelIndex& index) {
        QString selectedItem = model->data(index, Qt::DisplayRole).toString();

        if (pollutantDescriptions.contains(selectedItem)) {
            QString description = pollutantDescriptions[selectedItem];

            // Set the description text with formatting
            QString formattedDescription = "<p style='font-family:\"Times New Roman\"; font-size:14pt;'><b>" + selectedItem + "</b></p>";
            formattedDescription += "<p style='font-family:\"Times New Roman\"; font-size:12pt;'>" + description + "</p>";

            descriptionLabel->setText(formattedDescription);  // Update the label
        }
    });

    // Set the default description for the first item in the list
    if (!items.isEmpty()) {
        QString defaultItem = items.first();
        if (pollutantDescriptions.contains(defaultItem)) {
            QString description = pollutantDescriptions[defaultItem];

            // Set the description text with formatting
            QString formattedDescription = "<p style='font-family:\"Times New Roman\"; font-size:14pt;'><b>" + defaultItem + "</b></p>";
            formattedDescription += "<p style='font-family:\"Times New Roman\"; font-size:12pt;'>" + description + "</p>";

            descriptionLabel->setText(formattedDescription);  // Set default description
        }
    }

    // Top-left box: Search Bar and List View
    QFrame* topLeftBox = new QFrame(this);
    QVBoxLayout* topLeftLayout = new QVBoxLayout;
    topLeftLayout->addWidget(searchLineEdit);  // Add the QLineEdit to the topLeftBox
    topLeftLayout->addWidget(listView);  // Add the QListView to the topLeftBox
    topLeftBox->setLayout(topLeftLayout);
    topLeftBox->setFrameStyle(QFrame::Box);

    // Create the table widget and set its model
    table = new QTableView();
    table->setModel(&waterQualityModel);  // Set the model for the table

    // Set the table's size policy to allow it to fit inside the box
    table->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    // Declare top-right box: Layout to hold the table
    QFrame* topRightBox = new QFrame(this);
    QVBoxLayout* topRightLayout = new QVBoxLayout;
    topRightLayout->addWidget(table);  // Add the table to the top-right box
    topRightBox->setLayout(topRightLayout);
    topRightBox->setFrameStyle(QFrame::Box);

    // Bottom-left box: Additional Information
    QFrame* bottomLeftBox = new QFrame(this);
    QVBoxLayout* bottomLeftLayout = new QVBoxLayout;
    bottomLeftLayout->addWidget(descriptionLabel);  // Add the description label
    bottomLeftBox->setLayout(bottomLeftLayout);
    bottomLeftBox->setFrameStyle(QFrame::Box);

    // Declare bottom-right box: Placeholder for Graph
    QFrame* bottomRightBox = new QFrame(this);
    QVBoxLayout* bottomRightLayout = new QVBoxLayout;
    QLabel* bottomGraphPlaceholder = new QLabel("Graph Placeholder", this); // Placeholder text for the graph
    bottomRightLayout->addWidget(bottomGraphPlaceholder);
    bottomRightBox->setLayout(bottomRightLayout);
    bottomRightBox->setFrameStyle(QFrame::Box);

    // Top section layout (Horizontal layout with left and right boxes)
    QHBoxLayout* topLayout = new QHBoxLayout;
    topLayout->addWidget(topLeftBox, 4);  // Top-left box takes 40% width
    topLayout->addWidget(topRightBox, 6); // Top-right box takes 60% width

    // Bottom section layout (Horizontal layout with left and right boxes)
    QHBoxLayout* bottomLayout = new QHBoxLayout;
    bottomLayout->addWidget(bottomLeftBox, 4);  // Bottom-left box takes 40% width
    bottomLayout->addWidget(bottomRightBox, 6); // Bottom-right box takes 60% width

    // Final layout (Vertical layout)
    QVBoxLayout* finalLayout = new QVBoxLayout;
    finalLayout->addWidget(titleLabel);
    finalLayout->addLayout(topLayout);   // Add top section layout
    finalLayout->addLayout(bottomLayout); // Add bottom section layout

    // Set the final layout to the main widget
    setLayout(finalLayout);

    // Set the stretch factors for vertical layout (to ensure all boxes stretch vertically)
    topLayout->setStretchFactor(topLeftBox, 1);
    topLayout->setStretchFactor(topRightBox, 1);
    bottomLayout->setStretchFactor(bottomLeftBox, 1);
    bottomLayout->setStretchFactor(bottomRightBox, 1);

    // Set the size policy to expand vertically for all boxes
    topLeftBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    topRightBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    bottomLeftBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    bottomRightBox->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
}
