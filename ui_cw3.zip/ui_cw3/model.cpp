#include "model.hpp"
#include "dataset.hpp"

void WaterQualityModel::clear() {
    nitrateSamples.clear();  // Clear only the nitrateSamples if you are storing them separately
}

void WaterQualityModel::updateFromFile(const QString& filename) {
    beginResetModel();
    clear();
    dataset.loadData(filename.toStdString());  // Load full dataset (assuming nitrate samples are part of it)
    nitrateSamples = dataset.getNitrateSamples();  // Get nitrate samples after loading data
    endResetModel();
}

QVariant WaterQualityModel::data(const QModelIndex& index, int role) const {
    if (!index.isValid() || index.row() >= nitrateSamples.size()) {
        qDebug() << "Invalid index or out of range. Row:" << index.row() << "Size:" << nitrateSamples.size();
        return QVariant();
    }

    const WaterSample& sample = nitrateSamples[index.row()];

    if (role == Qt::TextAlignmentRole) {
        return int(Qt::AlignRight | Qt::AlignVCenter);
    } else if (role == Qt::DisplayRole) {
        // Handle Nitrate-N sample specific columns
        switch (index.column()) {
        case 0: return QVariant(sample.getId().c_str());
        case 1: return QVariant(sample.getDeterminandLabel().c_str());
        case 2: return QVariant(sample.getDateTime().c_str());
        case 3: return QVariant(QString::number(sample.getResult()));
        case 4: return QVariant(sample.getUnitLabel().c_str());
        case 5: return QVariant(sample.getCompliance() ? "Compliant" : "Non-Compliant");
        default:
            qDebug() << "Unhandled column index:" << index.column();
            return QVariant();
        }
    }

    return QVariant();
}

QVariant WaterQualityModel::headerData(int section, Qt::Orientation orientation, int role) const {
    if (role != Qt::DisplayRole) {
        return QVariant();
    }

    if (orientation == Qt::Vertical) {
        return QVariant(section + 1);  // For vertical headers (row numbers).
    }

    switch (section) {
    case 0: return QString("Sample ID");
    case 1: return QString("DeterminandLabel");
    case 2: return QString("Date & Time");
    case 3: return QString("Result");
    case 4: return QString("Unit Label");
    case 5: return QString("Compliance Status");
    default: return QVariant();
    }
}
