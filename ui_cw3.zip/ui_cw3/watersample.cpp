#include <stdexcept>
#include <sstream>
#include "watersample.hpp"
#include "dataset.hpp"
#include <fstream>

using namespace std;

std::ostream& operator<<(std::ostream& out, const WaterSample& sample) {
    // Check if the sample is related to Nitrate-N
    if (sample.getDeterminandLabel() == "Nitrate-N") {
        return out
               << "Sample ID: " << sample.getId() << "\n"
               << "Determinand Label: " << sample.getDeterminandLabel() << "\n"
               << "Date/Time: " << sample.getDateTime() << "\n"
               << "Result: " << sample.getResult() << " " << sample.getUnitLabel() << "\n"
               << "Compliance Status: " << (sample.getCompliance() ? "Compliant" : "Non-Compliant") << "\n";
    }

    // If not a Nitrate-N sample, just output a minimal message or full data (optional)
    return out
           << "Sample is not related to Nitrate-N. Sample ID: " << sample.getId() << "\n";
}
