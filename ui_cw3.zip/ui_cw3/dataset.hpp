#pragma once

#include <vector>
#include <string>
#include <QString> 
#include <fstream>
#include "watersample.hpp" 

struct FilteredSample {
	QString determinandLabel;
	QString dateTime;
	double result;
	QString unitLabel;
	double easting;
	double northing;
};

class WaterQualityDataset {
public:
    WaterQualityDataset() {}
    WaterQualityDataset(const std::string& filename) { loadData(filename); }
    void loadData(const std::string& filename);
    int size() const { return data.size(); }
    WaterSample operator[](int index) const { return data.at(index); }
    WaterSample highestResult() const;
    double meanResult() const;
    size_t complianceSampleCount() const;
    void clear() { data.clear(); } 
    
    const std::vector<WaterSample>& getData() const {
        return data;
    }
    std::vector<WaterSample> nitrateSamples; 
    std::vector<WaterSample> getNitrateSamples() const;
    std::vector<WaterSample> getAllSamples() const;
    
private:
    std::vector<WaterSample> data;
    void checkDataExists() const;
};
