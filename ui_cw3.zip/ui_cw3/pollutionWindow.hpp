#pragma once

#include <QWidget>
#include <QTableView>
#include <QStandardItemModel>
#include <QLabel>
#include <QLineEdit>
#include <QListWidget>
#include <QListView>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QFrame>
#include <QMap>
#include <QStringListModel>
#include <vector>
#include "model.hpp"
#include "dataset.hpp"
#include "watersample.hpp"
#include "stats.hpp"

class PollutionWindow : public QWidget {
    Q_OBJECT

public:
      PollutionWindow(QWidget* parent = nullptr);

private:
    void createMainWidget();
    QWidget *centralWidget;
    QMap<QString, QString> pollutantDescriptions;  
    QListWidget *pollutantsListWidget; 
    WaterQualityModel waterQualityModel;
    WaterQualityDataset dataset; 
    QTableView* table; 
};

