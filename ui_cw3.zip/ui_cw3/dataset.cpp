#include <stdexcept>
#include <algorithm>
#include <numeric>
#include "csv.hpp"
#include "watersample.hpp"
#include "dataset.hpp"

using namespace std;

void WaterQualityDataset::checkDataExists() const {
    if (data.empty()) {
        throw runtime_error("No data available in dataset.");
    }
}

WaterSample WaterQualityDataset::highestResult() const {
    checkDataExists();

    auto maxSample = *max_element(data.begin(), data.end(),
                                  [](const WaterSample& a, const WaterSample& b) {
                                      return a.getResult() < b.getResult();
                                  });

    return maxSample;
}

double WaterQualityDataset::meanResult() const {
    checkDataExists();

    double total = accumulate(data.begin(), data.end(), 0.0,
                              [](double sum, const WaterSample& sample) {
                                  return sum + sample.getResult();
                              });

    return total / data.size();
}

size_t WaterQualityDataset::complianceSampleCount() const {
    checkDataExists(); 

    return count_if(data.begin(), data.end(),
                    [](const WaterSample& sample) { return sample.getCompliance(); });
}

void WaterQualityDataset::loadData(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        throw std::runtime_error("Failed to open file: " + filename);
    }

    std::string line;
    bool firstLine = true;  // Flag to skip the header row

    while (std::getline(file, line)) {
        if (firstLine) {
            firstLine = false;  // Skip header row
            continue;
        }

        std::stringstream ss(line);

        std::string id, samplingPoint, samplingPointNotation, samplingPointLabel, dateTime, determinandLabel,
            determinandDefinition, determinandNotation, resultQualifier, codedResultInterpretation, unitLabel,
            sampledMaterialType, purposeLabel;
        std::string resultStr, complianceStr, eastingStr, northingStr;
        double result = 0.0, easting = 0.0, northing = 0.0;
        bool isComplianceSample = false;

        std::getline(ss, id, ',');
        std::getline(ss, samplingPoint, ',');
        std::getline(ss, samplingPointNotation, ',');
        std::getline(ss, samplingPointLabel, ',');
        std::getline(ss, dateTime, ',');
        std::getline(ss, determinandLabel, ',');
        std::getline(ss, determinandDefinition, ',');
        std::getline(ss, determinandNotation, ',');
        std::getline(ss, resultQualifier, ',');
        std::getline(ss, resultStr, ',');
        std::getline(ss, codedResultInterpretation, ',');
        std::getline(ss, unitLabel, ',');
        std::getline(ss, sampledMaterialType, ',');
        std::getline(ss, complianceStr, ',');
        std::getline(ss, purposeLabel, ',');
        std::getline(ss, eastingStr, ',');
        std::getline(ss, northingStr, ',');

        try {
            // Handle invalid result values (e.g., "<" or empty)
            if (!resultStr.empty() && resultStr != "<") {
                result = std::stod(resultStr);
            } else {
                result = 0.0;  // Set a default value for invalid result
            }

            // Handle easting and northing fields similarly
            if (!eastingStr.empty()) easting = std::stod(eastingStr);
            if (!northingStr.empty()) northing = std::stod(northingStr);

            // Validate compliance
            isComplianceSample = (complianceStr == "true" || complianceStr == "1");

            WaterSample sample(id, samplingPoint, samplingPointNotation, samplingPointLabel, dateTime, determinandLabel,
                               determinandDefinition, determinandNotation, resultQualifier, result, codedResultInterpretation,
                               unitLabel, sampledMaterialType, isComplianceSample, purposeLabel, easting, northing);

            data.push_back(sample);

            if (determinandLabel == "Nitrate-N") {
                nitrateSamples.push_back(sample);
            }
            std::cerr << "Number of Nitrate-N samples: " << nitrateSamples.size() << std::endl;
        } catch (const std::exception& e) {
        }
    }
    file.close();
}

std::vector<WaterSample> WaterQualityDataset::getNitrateSamples() const {
    return nitrateSamples;
}

std::vector<WaterSample> WaterQualityDataset::getAllSamples() const {
    return data;
}
