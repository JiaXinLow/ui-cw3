#pragma once

#include <string>
#include <iostream>

struct WaterSample {
    std::string id;                    // Sample ID
    std::string samplingPoint;         // Sampling point
    std::string samplingPointNotation; // Sampling point notation
    std::string samplingPointLabel;    // Sampling point label
    std::string dateTime;              // Date and time of the sample
    std::string determinandLabel;      // Determinand label
    std::string determinandDefinition; // Determinand definition
    std::string determinandNotation;  // Determinand notation
    std::string resultQualifier;       // Result qualifier
    double result;                     // Measurement result
    std::string codedResultInterpretation; // Coded result interpretation
    std::string unitLabel;             // Unit label
    std::string sampledMaterialType;   // Sampled material type
    bool isComplianceSample;           // Whether it's a compliance sample
    std::string purposeLabel;          // Sample purpose
    double easting;                    // Easting coordinate of the sampling point
    double northing;                   // Northing coordinate of the sampling point

    WaterSample(const std::string& id, const std::string& samplingPoint, const std::string& samplingPointNotation, 
                const std::string& samplingPointLabel, const std::string& dateTime, const std::string& determinandLabel, 
                const std::string& determinandDefinition, const std::string& determinandNotation, 
                const std::string& resultQualifier, double result, const std::string& codedResultInterpretation, 
                const std::string& unitLabel, const std::string& sampledMaterialType, bool isComplianceSample, 
                const std::string& purposeLabel, double easting, double northing)
        : id(id), samplingPoint(samplingPoint), samplingPointNotation(samplingPointNotation), samplingPointLabel(samplingPointLabel),
          dateTime(dateTime), determinandLabel(determinandLabel), determinandDefinition(determinandDefinition), 
          determinandNotation(determinandNotation), resultQualifier(resultQualifier), result(result),
          codedResultInterpretation(codedResultInterpretation), unitLabel(unitLabel), sampledMaterialType(sampledMaterialType),
          isComplianceSample(isComplianceSample), purposeLabel(purposeLabel), easting(easting), northing(northing) {}

    std::string getId() const { return id; }
    std::string getSamplingPoint() const { return samplingPoint; }
    std::string getSamplingPointNotation() const { return samplingPointNotation; }
    std::string getSamplingPointLabel() const { return samplingPointLabel; }
    std::string getDateTime() const { return dateTime; }
    std::string getDeterminandLabel() const { return determinandLabel; }
    std::string getDeterminandDefinition() const { return determinandDefinition; }
    std::string getDeterminandNotation() const { return determinandNotation; }
    std::string getResultQualifier() const { return resultQualifier; }
    double getResult() const { return result; }
    std::string getCodedResultInterpretation() const { return codedResultInterpretation; }
    std::string getUnitLabel() const { return unitLabel; }
    std::string getSampledMaterialType() const { return sampledMaterialType; }
    bool getCompliance() const { return isComplianceSample; }
    std::string getPurposeLabel() const { return purposeLabel; }
    double getEasting() const { return easting; }
    double getNorthing() const { return northing; }

    friend std::ostream& operator<<(std::ostream& out, const WaterSample& sample);
};