#include <stdexcept>
#include <sstream>
#include "watersample.hpp"
#include "dataset.hpp"
#include <fstream>

using namespace std;

std::ostream& operator<<(std::ostream& out, const WaterSample& sample) {
    return out
           << "Sample ID: " << sample.getId() << "\n"
           << "Sampling Point: " << sample.getSamplingPoint() << "\n"
           << "Sampling Point Notation: " << sample.getSamplingPointNotation() << "\n"
           << "Sampling Point Label: " << sample.getSamplingPointLabel() << "\n"
           << "Date/Time: " << sample.getDateTime() << "\n"
           << "Determinand Label: " << sample.getDeterminandLabel() << "\n"
           << "Determinand Definition: " << sample.getDeterminandDefinition() << "\n"
           << "Determinand Notation: " << sample.getDeterminandNotation() << "\n"
           << "Result Qualifier: " << (sample.getResultQualifier().empty() ? "N/A" : sample.getResultQualifier()) << "\n"
           << "Result: " << sample.getResult() << " " << sample.getUnitLabel() << "\n"
           << "Coded Result Interpretation: " << (sample.getCodedResultInterpretation().empty() ? "N/A" : sample.getCodedResultInterpretation()) << "\n"
           << "Sampled Material Type: " << sample.getSampledMaterialType() << "\n"
           << "Compliance Status: " << (sample.getCompliance() ? "Compliant" : "Non-Compliant") << "\n"
           << "Purpose Label: " << sample.getPurposeLabel() << "\n"
           << "Easting: " << sample.getEasting() << "\n"
           << "Northing: " << sample.getNorthing() << std::endl;
}

void WaterQualityDataset::loadData(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        throw std::runtime_error("Failed to open file: " + filename);
    }

    std::string line;
    bool firstLine = true;  // Flag to skip the header row

    while (std::getline(file, line)) {
        if (firstLine) {
            firstLine = false;  // Skip header row
            continue;
        }

        std::stringstream ss(line);

        std::string id, samplingPoint, samplingPointNotation, samplingPointLabel, dateTime, determinandLabel,
            determinandDefinition, determinandNotation, resultQualifier, codedResultInterpretation, unitLabel,
            sampledMaterialType, purposeLabel;
        std::string resultStr, complianceStr, eastingStr, northingStr;
        double result = 0.0, easting = 0.0, northing = 0.0;
        bool isComplianceSample = false;

        std::getline(ss, id, ',');
        std::getline(ss, samplingPoint, ',');
        std::getline(ss, samplingPointNotation, ',');
        std::getline(ss, samplingPointLabel, ',');
        std::getline(ss, dateTime, ',');
        std::getline(ss, determinandLabel, ',');
        std::getline(ss, determinandDefinition, ',');
        std::getline(ss, determinandNotation, ',');
        std::getline(ss, resultQualifier, ',');
        std::getline(ss, resultStr, ',');
        std::getline(ss, codedResultInterpretation, ',');
        std::getline(ss, unitLabel, ',');
        std::getline(ss, sampledMaterialType, ',');
        std::getline(ss, complianceStr, ',');
        std::getline(ss, purposeLabel, ',');
        std::getline(ss, eastingStr, ',');
        std::getline(ss, northingStr, ',');

        try {
            // Handle invalid result values (e.g., "<" or empty)
            if (!resultStr.empty() && resultStr != "<") {
                result = std::stod(resultStr);
            } else {
                result = 0.0;  // Set a default value for invalid result
            }

            // Handle easting and northing fields similarly
            if (!eastingStr.empty()) easting = std::stod(eastingStr);
            if (!northingStr.empty()) northing = std::stod(northingStr);

            // Validate compliance
            isComplianceSample = (complianceStr == "true" || complianceStr == "1");

            WaterSample sample(id, samplingPoint, samplingPointNotation, samplingPointLabel, dateTime, determinandLabel,
                               determinandDefinition, determinandNotation, resultQualifier, result, codedResultInterpretation,
                               unitLabel, sampledMaterialType, isComplianceSample, purposeLabel, easting, northing);

            data.push_back(sample);
        } catch (const std::exception& e) {
            // If you want to debug just errors, you can log only error messages instead
            std::cerr << "Error parsing row: " << line << ". Details: " << e.what() << std::endl;
        }
    }

    file.close();
}
