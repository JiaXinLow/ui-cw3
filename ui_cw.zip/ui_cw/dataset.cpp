#include <stdexcept>
#include <algorithm>
#include <numeric>
#include "csv.hpp"
#include "watersample.hpp"

using namespace std;

class WaterQualityDataset {
public:
    void loadData(const string& filename);
    WaterSample highestResult() const; 
    double meanResult() const;  
    size_t complianceSampleCount() const;

private:
    vector<WaterSample> data;
    void checkDataExists() const;
};

void WaterQualityDataset::checkDataExists() const {
    if (data.empty()) {
        throw runtime_error("No data available in dataset.");
    }
}

WaterSample WaterQualityDataset::highestResult() const {
    checkDataExists();

    auto maxSample = *max_element(data.begin(), data.end(),
                                  [](const WaterSample& a, const WaterSample& b) {
                                      return a.getResult() < b.getResult();
                                  });

    return maxSample;
}

double WaterQualityDataset::meanResult() const {
    checkDataExists();

    double total = accumulate(data.begin(), data.end(), 0.0,
                              [](double sum, const WaterSample& sample) {
                                  return sum + sample.getResult();
                              });

    return total / data.size();
}

size_t WaterQualityDataset::complianceSampleCount() const {
    checkDataExists(); 

    return count_if(data.begin(), data.end(),
                    [](const WaterSample& sample) { return sample.getCompliance(); });
}
