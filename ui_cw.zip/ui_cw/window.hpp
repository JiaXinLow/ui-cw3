#pragma once

#include <QMainWindow>
#include <QComboBox>
#include <QLabel>
#include <QPushButton>
#include <QTableView>
#include "model.hpp"

class StatsDialog;

class WaterQualityWindow : public QMainWindow
{
    Q_OBJECT

public:
    WaterQualityWindow(QWidget* parent = nullptr);

private:
    void createMainWidget();
    void createFileSelectors();
    void createButtons();
    void createToolBar();
    void createStatusBar();
    void addFileMenu();
    void addHelpMenu();

    WaterQualityModel waterQualityModel;
    QString dataLocation;
    QComboBox* countryFilter;
    QComboBox* yearFilter;
    QPushButton* loadButton;
    QPushButton* statsButton;
    QTableView* table; 
    QLabel* fileInfo;
    StatsDialog* statsDialog;

private slots:
    void setDataLocation();
    void openCSV();
    void displayStats();
    void about();
};
